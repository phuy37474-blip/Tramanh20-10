BẢN ĐĂNG WEB DỄ DÀNG BẰNG ĐIỆN THOẠI ANDROID

Bản này là website tĩnh, chỉ cần index.html nên có thể triển khai trên Render Static Site.
1. Giải nén ZIP.
2. Tạo repository GitHub và tải index.html lên thư mục gốc (root) của repository.
3. Vào Render > New + > Static Site, kết nối repository.
4. Build Command: để trống.
5. Publish Directory: .
6. Nhấn Deploy Site, sau khi thành công sao chép URL onrender.com để gửi.

Không cần Python hoặc requirements.txt cho bản static này.
